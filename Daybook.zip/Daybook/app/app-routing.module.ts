import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginModule } from './login/login.module';


export const routes: Routes = [

    { path: '', redirectTo: 'log/loginpage', pathMatch: 'full' },
    { path: 'log', loadChildren: 'LoginModule' },
    //{ path: 'config', loadChildren: 'ConfigurationModule' },
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: true })],
    exports: [RouterModule]
})


export class AppRoutingModule { }