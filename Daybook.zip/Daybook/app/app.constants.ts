﻿import { IMenu } from './ux/bmsmenu/bmsmenu.component'




export const AdminMenu: IMenu = {
    Title: '<i class="fa fa-id-card-o"></i> Administrator',
    Url: 'log/loginpage',
    Items: []
}


export const ProviderMenu: IMenu = {
    Title: '<i class="fa fa-home"></i> Provider',
    Url: 'log/loginpage',
    Items: []
}

export const PatientMenu: IMenu = {
    Title: '<i class="fa fa-id-card-o"></i> Patient',
    Url: 'log/request',
    Items: []
}





