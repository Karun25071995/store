import { Component } from '@angular/core'
import { AppConfig } from './app-config';
import { MaterialModuleControls } from './material-module';

@Component({
    selector: 'my-app',
    templateUrl: 'app.component.html',
    providers: [AppConfig]

})

export class AppComponent {

    public hideSideBar: boolean = true;
    toggleSideBar() {
        this.hideSideBar = !this.hideSideBar;
    }

}