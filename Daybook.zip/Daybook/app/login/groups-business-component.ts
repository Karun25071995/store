﻿import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { AdamComponent} from './adam-component';
import { DeleteBusinessComponent } from './delete-business-component';
import { GroupsBusinessUpdateComponent} from './groups-business-update-component';
import { InvitePopComponent} from './invite-pop-component';
import { CustomerCreditComponent} from './customer-credit-component';
import { CustomerCreditAbcComponent} from './customer-credit-abc-component';
import { PinToDashboardComponent } from './pin-to-dashboard-component';

@Component({
    selector: 'groups-business-component',
    templateUrl: 'groups-business-component.html'
})

export class GroupsBusinessComponent {

    imgPath: string = "./images/no.jpg"
    imgPath1: string = "./images/home.svg"

    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog
    ) {
        this.shared.login = true;
    }

    Left() {
        this.router.navigate(['log/business']);
    }

    Back() {
        this.router.navigate(['log/business']);
    }

    calender() {

        this.router.navigate(['log/BusinessScheduler']);
    }

     getAdam() {
        let dialogOpen = this.dialog.open(AdamComponent, {
            width: '40%',
            disableClose: true
        })
    }

    deleteDetails() {
        let dialogOpen = this.dialog.open(DeleteBusinessComponent, {
            width: '20%',
            disableClose: true
        })
    }
    pin() {
        let dialogOpen = this.dialog.open(PinToDashboardComponent, {
            width: '20%',
            disableClose: true
        })
    }

    Update() {
        let dialogOpen = this.dialog.open(GroupsBusinessUpdateComponent, {
            width: '40%',
             disableClose: true
        })
    }

    invite() {
        let dialogOpen = this.dialog.open(InvitePopComponent, {
            width: '40%',
            disableClose: true
        })
    }

    XYZ() {
        let dialogOpen = this.dialog.open(CustomerCreditComponent, {
            width: '40%',
            disableClose: true
        })
    }

    ABC() {
        let dialogOpen = this.dialog.open(CustomerCreditAbcComponent, {
            width: '40%',
            disableClose: true
        })
    }
    //CreateSchedule() {
    //    this.router.navigate(['log/BusinessScheduler']);
    //}
}