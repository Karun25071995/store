﻿import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';




@Component({
    selector: 'my-doctor-update-component',
    templateUrl: 'my-doctor-update-component.html'
})

export class MyDoctorUpdateComponent {


    imgPath5: string = "./images/no.jpg"

    constructor(

        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog,
        public dialogRef: MatDialogRef<MyDoctorUpdateComponent>) {




    }




    closePopUp() {
        this.dialogRef.close();
    }



}