﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'cancel-component',
    templateUrl: 'cancel-component.html'
})

export class CancelComponent {
    constructor(public dialogRef: MatDialogRef<CancelComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}