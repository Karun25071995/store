﻿import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { MaterialModuleControls } from '../material-module';
import { SharedData } from '../shared/shareddata';
import { AppConfig } from '../app-config';


@Component({
    selector: 'login',
    templateUrl: 'login.component.html',
    providers: [AppConfig]
})

export class LoginComponent {

    imgPath: string = "./images/my_ui.png"
   
    

    loginUser = new FormControl('', [Validators.required]);
    loginRole = new FormControl('', [Validators.required]);
    loginFacility = new FormControl('');

    userName: string;
    passwordtxt: string;

    facilities = [
        { value: '1', viewValue: 'St Elizabeth Mission Hospital' }
        //{ value: '2', viewValue: 'St Elizabeth Memorial Hospital' }

    ]

    roles = [
        { value: '1', viewValue: 'Individual' },
        { value: '2', viewValue: 'Business' },

    ]




    constructor(private shared: SharedData, private router: Router) {
        this.shared.login = false;
    }

    indRegistration() {
        this.router.navigate(['log/individual-registration']);
    }

   bussRegistration() {
       this.router.navigate(['log/business-registration']);
    }


    loginClick() {

        this.shared.LoginUser = { "UserName": 'Adam', "Password": 'Good', "Facility": '', "Role": 'Individual' };

        if (this.shared.LoginUser.Role == "Individual") {
            this.router.navigate(['log/individual']);
        }

    }


    businessClick() {

        this.shared.LoginUser = { "UserName": 'Adam', "Password": 'Good', "Facility": '', "Role": 'Individual' };

        if (this.shared.LoginUser.Role == "Individual") {
            this.router.navigate(['log/business']);

        }


    }

}