﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'delete-saleshistory-component',
    templateUrl: 'delete-saleshistory-component.html'
})

export class DeleteSaleHistoryComponent {
    constructor(public dialogRef: MatDialogRef<DeleteSaleHistoryComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}