﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'dismisspop-component',
    templateUrl: 'dismisspop-component.html'
})

export class DismissPopComponent {
    constructor(public dialogRef: MatDialogRef<DismissPopComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}