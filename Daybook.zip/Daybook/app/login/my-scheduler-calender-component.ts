﻿import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
declare var $: any;

@Component({
    selector: 'my-scheduler-calender-component',
    templateUrl: 'my-scheduler-calender-component.html'
})


export class MySchedulerCalenderComponent implements OnInit {




    imgPath: string = "./images/home.svg"

    constructor(
        private router: Router,
        private shared: SharedData
    ) {
        this.shared.login = true;
    }


    ngOnInit() {

        $(document).ready(function () {

            $('#calendar').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'agendaDay,month,agendaWeek,listWeek'
                },
                defaultDate: this.testdate,
                navLinks: true, // can click day/week names to navigate views
                editable: true,
                allDaySlot: false,
                allDayText: false,
                eventLimit: true, // allow "more" link when too many events
                defaultView: 'month',


                events: [

                    {
                        id: 999,
                        title: 'Repeating Event',
                        start: '2018-04-14T16:00:00'
                    },
                    {
                        id: 999,
                        title: 'Repeating Event',
                        start: '2018-04-16T16:00:00'
                    },
                    {
                        title: 'Yoga',
                        start: '2018-06-02T06:00:00'
                    },
                    {
                        title: 'Music',
                        start: '2018-06-02T19:00:00'
                    },

                    {
                        title: 'Dance',
                        start: '2018-06-03T16:00:00'
                    },

                    {
                        title: 'Aerobics',
                        start: '2018-06-03T10:00:00'
                    },


                ]
            });

        });
    }

    turn() {
        this.router.navigate(["log/-my"]);
    }


    Back() {
        this.router.navigate(["log/individual"]);
    }


}