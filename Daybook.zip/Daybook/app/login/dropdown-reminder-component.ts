﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'dropdown-reminder-component',
    templateUrl: 'dropdown-reminder-component.html'
})

export class DropdownReminderComponent {
    constructor(public dialogRef: MatDialogRef<DropdownReminderComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}