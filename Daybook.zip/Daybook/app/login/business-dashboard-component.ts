﻿import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { CancelComponent } from './cancel-component';
import { JoinPopIndividualDashboardComponent } from './join-pop-individual-dashboard-component';
import { CancelReminderProfileIndividualComponent } from './cancel-reminder-profile-component';
import { DismissPopComponent } from './dismisspop-component';
import { EmilyGreenDetailComponent} from './emily-green-detail-component';

@Component({
    selector: 'business-dashboard-component',
    templateUrl: 'business-dashboard-component.html'
})

export class BusinessDashboardComponent implements OnInit {

    imgPath1: string = "./images/group.svg"
    imgPath2: string = "./images/balloon.svg"
    imgPath3: string = "./images/customer.svg"
    imgPath4: string = "./images/icon.svg"
    imgPath5: string = "./images/bag.svg"
    imgPath6: string = "./images/sale.svg"
    imgPath7: string = "./images/id-card.svg"
    imgPath8: string = "./images/coupon.svg"
    imgPath9: string = "./images/gmail.svg"
    imgPath0: string = "./images/calendar.svg"
    imPath: string = "./images/invoice.svg"
    




    public print: any;
    public excel: any;

    ngOnInit() {

      



        this.print = './images/print.png';
        this.excel = './images/excel.png';

      
            
       





    }
    constructor(
        private router: Router,
        private shared: SharedData,
         private dialog: MatDialog
    ) {
        this.shared.login = true;
    }

    Move() {
        this.router.navigate(['log/loginpage']);
    }

    CreateSchedule() {
        this.router.navigate(['log/BusinessScheduler']);
    }

    GoEvents() {
        this.router.navigate(["log/eventsBusiness"]);
    }

    GoGroups() {
        this.router.navigate(["log/groupsBusiness"]);
    }
    GoMembers() {
        this.router.navigate(["log/membersBusiness"]);
    }

    GoAdditional() {
        this.router.navigate(["log/additional-business"]);
    }

    GoItems() {
        this.router.navigate(["log/items-business"]);
    }

    GoSales() {
        this.router.navigate(["log/saleshistory-business"]);
    }

    GoStaff() {
        this.router.navigate(["log/staff"]);
    }
    GoCoupons() {
        this.router.navigate(["log/coupons"]);
    }

    GoEmail() {
        this.router.navigate(["log/email"]);
    }

    viewtemplate() {
        this.router.navigate(["log/-invoice"]);

    }


    Profile(){
        this.router.navigate(["log/profile-business"]);
    }

    getCancelDetails() {
        let dialogOpen = this.dialog.open(CancelComponent, {
            width: '20%',
            disableClose: true
        })
    }

    openJoinPop() {
        let dialogOpen = this.dialog.open(JoinPopIndividualDashboardComponent, {
            width: '20%',
            disableClose: true
        })
    }
    cancelDetails() {
        let dialogOpen = this.dialog.open(CancelReminderProfileIndividualComponent, {
            width: '20%',
            disableClose: true
        })
    }

    Dismiss() {
        let dialogOpen = this.dialog.open(DismissPopComponent, {
            width: '20%',
            disableClose: true
        })
    }

    getEmily() {
        let dialogOpen = this.dialog.open(EmilyGreenDetailComponent, {
            width: '40%',
            disableClose: true
        })
    }

}