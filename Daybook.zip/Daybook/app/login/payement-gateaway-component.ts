﻿import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { SuccessfullMessageComponent} from './successfull-message-component';
import { InvoiceBusinessTemplateComponent} from './invoice-business-template-component';


@Component({
    selector: 'payement-gateaway-component',
    templateUrl: 'payement-gateaway-component.html'
})

export class PayementGateAwayComponent {

   
    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog

    ) {
        this.shared.login = true;
    }

    Left() {
        this.router.navigate(['log/items-business'])
    }

    SubmitClick() {
        this.router.navigate(['log/view-invoice'])
    }

}