﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'unpin-pop-component',
    templateUrl: 'unpin-pop-component.html'
})

export class UnpinPopComponent {
    constructor(public dialogRef: MatDialogRef<UnpinPopComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}