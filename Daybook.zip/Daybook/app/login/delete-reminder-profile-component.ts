﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'delete-reminder-profile-component',
    templateUrl: 'delete-reminder-profile-component.html'
})

export class DeleteReminderProfileIndividualComponent {
    constructor(public dialogRef: MatDialogRef<DeleteReminderProfileIndividualComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}