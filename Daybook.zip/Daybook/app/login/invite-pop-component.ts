﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'invite-pop-component',
    templateUrl: 'invite-pop-component.html'
})

export class InvitePopComponent {


    

    constructor(public dialogRef: MatDialogRef<InvitePopComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}