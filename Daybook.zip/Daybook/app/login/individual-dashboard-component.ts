﻿import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { HotelDashboardComponent } from './hotel-detail-dashboard-component';
import { SalonDashboardComponent } from './salon-detail-dashboard-component';
import { DoctorDashboardComponent } from './doctor-detail-dashboard-component';
import { CancelComponent } from './cancel-component';
import { SearchPopComponent} from './searchpop-component';
import { JoinPopIndividualDashboardComponent } from './join-pop-individual-dashboard-component';
import { CancelReminderProfileIndividualComponent } from './cancel-reminder-profile-component';
import { UnpinPopComponent } from './unpin-pop-component';
import { DismissPopComponent } from './dismisspop-component';

@Component({
    selector: 'individual-dashboard-component',
    templateUrl: 'individual-dashboard-component.html'
})

export class IndividualDashboardComponent implements OnInit {



    private reminderArray: Array<any> = [];
    private newAttribute: any = {};

    addFieldValue() {
        this.reminderArray.push(this.newAttribute)
        this.newAttribute = {};
    }

    deleteFieldValue(index) {
        this.reminderArray.splice(index, 1);
    }



    imgPath: string = "./images/settings.svg"
    imgPath1: string = "./images/dog.svg"
    imgPath2: string = "./images/doctor.svg"
    imgPath3: string = "./images/calendar.svg"
    imgPath4: string = "./images/group.svg"
    imgPath5: string = "./images/balloon.svg"
    imgPath6: string = "./images/icon.svg"
   
    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog

    ) {
        this.shared.login = true;
    }

    ngOnInit() {




    }
    DoctorSchedule() {
        this.router.navigate(['log/-doctorschedule']);
    }

    mySchedule() {
        this.router.navigate(['log/-my']);
    }

    HouseSchedule() {
        this.router.navigate(['log/-myhouse']);
    }

    myAuto() {
        this.router.navigate(['log/-auto']);
    }

    Pet() {
        this.router.navigate(['log/-pet']);
    }


    ProfileClick() {
        this.router.navigate(['log/profile']);
    }

    GoBack() {
        this.router.navigate(['log/loginpage']);
    }

    CreateSchedule() {
        this.router.navigate(["log/scheduler"]);
    }

    GoEvents() {
        this.router.navigate(["log/events"]);
    }

    GoGroups() {
        this.router.navigate(["log/groups"]);
    }

    GoAdditional() {
        this.router.navigate(["log/additional"]);
    }



    //getHotelDetails() {
    //    let dialogOpen = this.dialog.open(HotelDashboardComponent, {
    //        width: '25%',
    //        disableClose: true
    //    })
    //}

    getHouseDetails() {
        this.router.navigate(["log/-myhouse"]);
    }


    //getSalonDetails() {
    //    let dialogOpen = this.dialog.open(SalonDashboardComponent, {
    //        width: '25%',
    //        disableClose: true
    //    })
    //}

    getDogDetails() {
        this.router.navigate(["log/-pet"]);
    }

    Unpin() {
        let dialogOpen = this.dialog.open(UnpinPopComponent, {
            width: '20%',
            disableClose: true
        })
    }

    getDoctorDetails() {
        this.router.navigate(["log/-doctorschedule"]);

    }
   

    getCancelDetails() {
        let dialogOpen = this.dialog.open(CancelComponent, {
            width: '20%',
            disableClose: true
        })
    }

    getSearch() {
        let dialogOpen = this.dialog.open(SearchPopComponent, {
            width: '40%',
            disableClose: true
        })
    }

    openJoinPop() {
        let dialogOpen = this.dialog.open(JoinPopIndividualDashboardComponent, {
            width: '20%',
            disableClose: true
        })
    }

    cancelDetails() {
        let dialogOpen = this.dialog.open(CancelReminderProfileIndividualComponent, {
            width: '20%',
            disableClose: true
        })
    }


    Dismiss() {
        let dialogOpen = this.dialog.open(DismissPopComponent, {
            width: '20%',
            disableClose: true
        })
    }
}