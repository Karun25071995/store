﻿import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { CancelComponent } from './cancel-component';

@Component({
    selector: 'business-registration-component',
    templateUrl: 'business-registration-component.html'
})

export class BusinessRegistrationComponent {




    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog
    ) {
        this.shared.login = true;
    }

    Left() {
        this.router.navigate(['log/loginpage']);
    }



}