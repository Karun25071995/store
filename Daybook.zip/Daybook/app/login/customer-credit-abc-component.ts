﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'customer-credit-abc-component',
    templateUrl: 'customer-credit-abc-component.html'
})

export class CustomerCreditAbcComponent {
    constructor(public dialogRef: MatDialogRef<CustomerCreditAbcComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}