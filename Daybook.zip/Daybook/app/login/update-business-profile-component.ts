﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'update-business-profile-component',
    templateUrl: 'update-business-profile-component.html'
})

export class UpdateBusinessProfileComponent {


    imgPath: string = "./images/garage.jpg"

    constructor(public dialogRef: MatDialogRef<UpdateBusinessProfileComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}