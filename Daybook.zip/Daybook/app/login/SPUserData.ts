﻿export class SPUserData {
    public UserName: string; public Password: string; public Facility: string; public Role: string;
}

