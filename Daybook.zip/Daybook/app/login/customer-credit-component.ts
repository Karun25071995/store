﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'customer-credit-component',
    templateUrl: 'customer-credit-component.html'
})

export class CustomerCreditComponent {
    constructor(public dialogRef: MatDialogRef<CustomerCreditComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}