﻿import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { CancelComponent } from './cancel-component';
import { NoViewInvoiceTemplateComponent} from './noview-invoice-template-component';

@Component({
    selector: 'invoice-business-template-component',
    templateUrl: 'invoice-business-template-component.html'
})

export class InvoiceBusinessTemplateComponent {

    imgPath1: string = "./images/invoice.png"
    imgPath: string = "./images/home.svg"

    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog
    ) {
        this.shared.login = true;
    }

    View() {
        this.router.navigate(['log/noview-invoice'])
    }


    Left() {
        this.router.navigate(['log/business'])
    }


   
}