﻿import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';


@Component({
    selector: 'additional-features-component',
    templateUrl: 'additional-features-component.html'
})

export class AdditionalFeaturesComponent {


    imgPath: string = "./images/home.svg"

    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog
    ) {
        this.shared.login = true;
    }

    Back() {
        this.router.navigate(['log/individual']);
    }

    //getAdam() {
    //    let dialogOpen = this.dialog.open(AdamComponent, {
    //        width: '30%',
    //        disableClose: true
    //    })
    //}

    //CreateSchedule() {
    //    this.router.navigate(['log/BusinessScheduler']);
    //}
}