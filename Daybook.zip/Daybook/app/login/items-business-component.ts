﻿import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { SalesPopComponent} from './salespop-component';
import { DeleteBusinessComponent} from './delete-business-component';
import { ItemBusinessUpdateComponent } from './item-business-update-component';

@Component({
    selector: 'items-business-component',
    templateUrl: 'items-business-component.html'
})

export class ItemsBusinessComponent {

    imgPath1: string = "./images/no.jpg"
    imgPath: string = "./images/home.svg"

    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog
    ) {
        this.shared.login = true;
    }

    Left() {
        this.router.navigate(['log/business'])
    }

    Back() {
        this.router.navigate(['log/business'])
    }



    Item() {
        this.router.navigate(['log/payement'])
    }

    getSalespop() {
        let dialogOpen = this.dialog.open(SalesPopComponent, {
            width: '40%',
            disableClose: true
        })
    }

    deleteBusiness() {
        let dialogOpen = this.dialog.open(DeleteBusinessComponent, {
            width: '20%',
            disableClose: true
        })
    }

    update() {
        let dialogOpen = this.dialog.open(ItemBusinessUpdateComponent, {
            width: '40%',
            disableClose: true
        })
    }

    //CreateSchedule() {
    //    this.router.navigate(['log/BusinessScheduler']);
    //}
}