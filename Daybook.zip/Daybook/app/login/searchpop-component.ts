﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'searchpop-component',
    templateUrl: 'searchpop-component.html'
})

export class SearchPopComponent {

    
    image1: string = "./images/hair.svg"
   
    image3: string = "./images/airplane.svg"
    image4: string = "./images/gym.svg"
    image5: string = "./images/transfusion.svg"
 
    image7: string = "./images/cart.svg"
    image8: string = "./images/meeting.svg"

    constructor(public dialogRef: MatDialogRef<SearchPopComponent>) {

     

    }

    closePopUp() {
        this.dialogRef.close();
    }

     
}