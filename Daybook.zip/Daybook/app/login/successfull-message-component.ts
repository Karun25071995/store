﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'successfull-message-component',
    templateUrl: 'successfull-message-component.html'
})

export class SuccessfullMessageComponent {
    constructor(public dialogRef: MatDialogRef<SuccessfullMessageComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}