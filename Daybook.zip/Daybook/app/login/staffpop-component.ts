﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'staffpop-component',
    templateUrl: 'staffpop-component.html'
})

export class StaffPopComponent {

    imgPath1: string = "./images/no.jpg"
    constructor(public dialogRef: MatDialogRef<StaffPopComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}