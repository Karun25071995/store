﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'block-component',
    templateUrl: 'block-component.html'
})

export class BlockComponent {
    constructor(public dialogRef: MatDialogRef<BlockComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}