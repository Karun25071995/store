﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'join-pop-individual-dashboard-component',
    templateUrl: 'join-pop-individual-dashboard-component.html'
})

export class JoinPopIndividualDashboardComponent {
    constructor(public dialogRef: MatDialogRef<JoinPopIndividualDashboardComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}