﻿import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { CancelComponent } from './cancel-component';

@Component({
    selector: 'email-template-component',
    templateUrl: 'email-template-component.html'
})

export class EmailTemplateComponent {

    imgPath1: string = "./images/email.png"
    imgPath: string = "./images/home.svg"

    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog
    ) {
        this.shared.login = true;
    }

    viewtemplate() {
        this.router.navigate(['log/noview']);
    }

    View() {
        this.router.navigate(['log/view']);
    }


    Back() {
        this.router.navigate(['log/business'])
    }


    Left() {
        this.router.navigate(['log/business'])
    }
}