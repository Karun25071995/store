﻿import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { EditorModule } from '@tinymce/tinymce-angular';
import { MatDialog } from '@angular/material';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
//declare var $: any;

@Component({
    selector: 'view-template-component',
    templateUrl: 'view-template-component.html'
})

export class ViewTemplateComponent /*implements OnInit*/ {


 
    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog
    ) {
        this.shared.login = true;
    }
    //ngOnInit() {
        
    //        $(document).ready(function () {
    //            $('#summernote').summernote();
    //        });
        
    //}
    //Left() {
    //    this.router.navigate(['log/loginpage']);
    //}

    Left() {
        this.router.navigate(['log/email'])
    }


}