﻿import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
declare var $: any;

@Component({
    selector: 'business-scheduler-dashboard-component',
    templateUrl: 'business-scheduler-dashboard-component.html'
})


export class BusinessSchedulerComponent implements OnInit {

    imgPath: string = "./images/home.svg"

    constructor(
        private router: Router,
        private shared: SharedData
    ) {
        this.shared.login = true;
    }


    ngOnInit() {

        $(document).ready(function () {

            $('#calendar').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'agendaDay,month,agendaWeek,listWeek'
                },
                defaultDate: this.testdate,
                navLinks: true, // can click day/week names to navigate views
                editable: true,
                allDaySlot: false,
                allDayText: false,
                eventLimit: true, // allow "more" link when too many events
                defaultView: 'month',

                events: [

                    {
                        id: 999,
                        title: 'Repeating Event',
                        start: '2018-04-14T16:00:00'
                    },
                    {
                        id: 999,
                        title: 'Repeating Event',
                        start: '2018-04-16T16:00:00'
                    },

                    {
                        title: 'Meeting',
                        start: '2018-04-13T11:30:00',
                        end: '2018-04-13T12:30:00'
                    },
                    {
                        title: 'Lunch',
                        start: '2018-04-13T1:00:00'
                    },
                    {
                        title: 'Meeting',
                        start: '2018-04-13T18:30:00'
                    },

                    {
                        title: 'Dinner',
                        start: '2018-04-13T20:00:00'
                    },
                    {
                        title: 'Birthday Party',
                        start: '2018-04-14T07:00:00'
                    }
                ]
            });

        });
    }
    turn() {
        this.router.navigate(["log/business"]);
    }

}