﻿import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
declare var $: any;

@Component({
    selector: 'my-pet-calender-component',
    templateUrl: 'my-pet-calender-component.html'
})


export class MyPetCalenderComponent implements OnInit {




    imgPath: string = "./images/home.svg"

    constructor(
        private router: Router,
        private shared: SharedData
    ) {
        this.shared.login = true;
    }


    ngOnInit() {

        $(document).ready(function () {

            $('#calendar').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'agendaDay,month,agendaWeek,listWeek'
                },
                defaultDate: this.testdate,
                navLinks: true, // can click day/week names to navigate views
                editable: true,
                allDaySlot: false,
                allDayText: false,
                eventLimit: true, // allow "more" link when too many events
                defaultView: 'month',


                events: [

                    {
                        id: 999,
                        title: 'Repeating Event',
                        start: '2018-04-14T16:00:00'
                    },
                    {
                        id: 999,
                        title: 'Repeating Event',
                        start: '2018-04-16T16:00:00'
                    },
                   
                    {
                        title: 'Grooming',
                        start: '2018-05-31T10:00:00'
                    },
                    {
                        title: 'Vet Doctor',
                        start: '2018-05-31T10:00:00'
                    },

                    {
                        title: 'Vaccination',
                        start: '2018-06-01T10:30:00'
                    },

                    {
                        title: 'Walking',
                        start: '2018-06-01T18:00:00'
                    },
                ]
            });

        });
    }

    turn() {
        this.router.navigate(["log/-pet"]);
    }
    Back() {
        this.router.navigate(["log/individual"]);
    }
}