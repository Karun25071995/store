﻿import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { AdamComponent} from './adam-component';
import { DeleteBusinessComponent } from './delete-business-component';
import { EventsUpdateComponent} from './events-update-component';

@Component({
    selector: 'events-individual-component',
    templateUrl: 'events-individual-component.html'
})

export class EventsIndividualComponent  {


    imgPath1: string = "./images/no.jpg"
    imgPath: string = "./images/home.svg"
    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog
    ) {
        this.shared.login = true;
    }

    Left() {
        this.router.navigate(['log/individual']);
    }

    getAdam() {
        let dialogOpen = this.dialog.open(AdamComponent, {
            width: '40%',
            disableClose: true
        })
    }

    deleteDetails() {
        let dialogOpen = this.dialog.open(DeleteBusinessComponent, {
            width: '20%',
            disableClose: true
        })
    }

    eventsupdate() {
        let dialogOpen = this.dialog.open(EventsUpdateComponent, {
            width: '40%',
            disableClose: true
        })
    }


    //CreateSchedule() {
    //    this.router.navigate(['log/BusinessScheduler']);
    //}
}