﻿import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { AdamComponent } from './adam-component';
import { DeleteBusinessComponent} from './delete-business-component';
import { GroupsUpdateComponent} from './groups-update-component';
import { InvitePopComponent} from './invite-pop-component';
import { CreditPointsComponent} from './credit-points-component';
import { PinToDashboardComponent } from './pin-to-dashboard-component';
@Component({
    selector: 'groups-individual-component',
    templateUrl: 'groups-individual-component.html'
})

export class GroupsIndividualComponent /*implements OnInit*/ {

    //public reminderArray: Array<any> = [];
    //public newAttribute = {



    //    'SNo': '3',
    //    'Groups': 'ABC',
    //    'Created Date': '04/23/2018',
        




    //};

    //addFieldValue() {
    //    this.reminderArray.push(this.newAttribute);
    //}

    //deleteFieldValue(index) {
    //    this.reminderArray.splice(index, 1);
    //}








    imgPath: string = "./images/no.jpg"
    imgPath1: string = "./images/home.svg"


    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog
    ) {
        this.shared.login = true;
    }

    ngOnInit() {

    }


    Left() {
        this.router.navigate(['log/individual']);
    }

    getAdam() {
        let dialogOpen = this.dialog.open(AdamComponent, {
            width: '40%',
            disableClose: true
        })
    }

    deleteDetails() {
        let dialogOpen = this.dialog.open(DeleteBusinessComponent, {
            width: '20%',
            disableClose: true
        })
    }

    credit() {
        let dialogOpen = this.dialog.open(CreditPointsComponent, {
            width: '40%',
            disableClose: true
        })
    }

    pin() {
        let dialogOpen = this.dialog.open(PinToDashboardComponent, {
            width: '20%',
            disableClose: true
        })
    }



    groupsupdate() {
        let dialogOpen = this.dialog.open(GroupsUpdateComponent, {
            width: '40%',
            disableClose: true
        })
    }
    invite() {
        let dialogOpen = this.dialog.open(InvitePopComponent, {
            width: '20%',
            disableClose: true
        })
    }
    //CreateSchedule() {
    //    this.router.navigate(['log/BusinessScheduler']);
    //}
}