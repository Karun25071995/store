﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'salon-detail-dashboard-component',
    templateUrl: 'salon-detail-dashboard-component.html'
})

export class SalonDashboardComponent {
    constructor(public dialogRef: MatDialogRef<SalonDashboardComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}