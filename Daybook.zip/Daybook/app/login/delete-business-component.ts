﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'delete-business-component',
    templateUrl: 'delete-business-component.html'
})

export class DeleteBusinessComponent {
    constructor(public dialogRef: MatDialogRef<DeleteBusinessComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}