﻿import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { MembersTransactionComponent } from './members-transaction-component';



@Component({
    selector: 'adam-component',
    templateUrl: 'adam-component.html'
})

export class AdamComponent {


    imgPath1: string = "./images/men.jpg"

    constructor(

        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog,
        public dialogRef: MatDialogRef<AdamComponent>) {



       
    }

   
       
     
    closePopUp() {
        this.dialogRef.close();
    }


    getTransaction() {
        let dialogOpen = this.dialog.open(MembersTransactionComponent, {
            width: '40%',
            disableClose: true
        })
    }
}