﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'salespop-component',
    templateUrl: 'salespop-component.html'
})

export class SalesPopComponent {

    imgPath1: string = "./images/no.jpg"

    constructor(public dialogRef: MatDialogRef<SalesPopComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}