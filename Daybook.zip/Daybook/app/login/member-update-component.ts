﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'member-update-component',
    templateUrl: 'member-update-component.html'
})

export class MemberUpdateComponent {

    imgPath1: string = "./images/no.jpg"

    constructor(public dialogRef: MatDialogRef<MemberUpdateComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}