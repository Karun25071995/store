﻿import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EditorModule } from '@tinymce/tinymce-angular';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BMSUxModule } from '../ux/bms.ux.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
//Custom Module
import { AppConfig } from '../app-config';

import { MaterialModuleControls } from '../material-module';
import { LoginRoutingModule } from './login-routing.module';



//Custom components
import { LoginComponent } from './login.component';
import { IndividualDashboardComponent } from './individual-dashboard-component';
import { BusinessDashboardComponent } from './business-dashboard-component';
import { ProfileIndividualComponent } from './profile-individual-component';
import { SchedulerComponent } from './scheduler-component';
import { BusinessSchedulerComponent } from './business-scheduler-dashboard-component';
import { HotelDashboardComponent } from './hotel-detail-dashboard-component';
import { SalonDashboardComponent } from './salon-detail-dashboard-component';
import { DoctorDashboardComponent} from './doctor-detail-dashboard-component';
import { EventsIndividualComponent } from './events-individual-component';
import { GroupsIndividualComponent } from './groups-individual-component';
import { CancelComponent } from './cancel-component';
import { EventsBusinessComponent} from './events-business-component';
import { GroupsBusinessComponent} from './groups-business-component';
import { MembersBusinessComponent } from './members-business-component';
import { ProfileBusinessComponent } from './profile-business-component';
import { AdditionalFeaturesComponent} from './additional-features-component';
import { BusinessAdditionalComponent} from './business-additional-component';
import { AdamComponent } from './adam-component';
import { SearchPopComponent} from './searchpop-component';
import { ItemsBusinessComponent} from './items-business-component';
import { SalesHistoryBusinessComponent} from './sale-history-business-component';
import { SalesPopComponent} from './salespop-component';
import { DeleteSaleHistoryComponent } from './delete-saleshistory-component';
import { MembersTransactionComponent} from './members-transaction-component';
import { SuccessfullMessageComponent} from './successfull-message-component';
import { PayementGateAwayComponent } from './payement-gateaway-component';
import { StaffBusinessComponent} from './staff-business-component';
import { StaffPopComponent } from './staffpop-component';
import { IndividualRegistrationComponent } from './individual-registration-component';
import { BusinessRegistrationComponent } from './business-registration-component';
import { CouponsBusinessComponent} from './coupons-business-component';
import { EmailTemplateComponent } from './email-template-component';
import { ViewTemplateComponent} from './view-template-component';
import { NoViewTemplateComponent} from './noview-template-component';
import { ProfileIndividualPopComponent } from './profile-ind-pop-component';
import { IndividualProfileReminderPopComponent} from './ind-reminder-pop-component';
import { DeleteReminderProfileIndividualComponent} from './delete-reminder-profile-component';
import { CancelReminderProfileIndividualComponent } from './cancel-reminder-profile-component';
import { JoinPopIndividualDashboardComponent } from './join-pop-individual-dashboard-component';
import { UpdateBusinessProfileComponent} from './update-business-profile-component';
import { ReminderBusinessProfileComponent} from './reminder-business-profile-component';
import { DeleteBusinessComponent } from './delete-business-component';
import { GroupsUpdateComponent} from './groups-update-component';
import { EventsUpdateComponent} from './events-update-component';
import { EventsBusinessUpdateComponent} from './events-business-update-component';
import { GroupsBusinessUpdateComponent } from './groups-business-update-component';
import { ViewInvoiceTemplateComponent} from './view-invoice-template-component';
import { InvoiceBusinessTemplateComponent} from './invoice-business-template-component';
import { DoctorSchedulerComponent } from './doctor-schedule-component';
import { MySchedulerComponent} from './my-schedule-component';
import { MyHouseSchedulerComponent} from './my-house-schedule-component';
import { MyAutoSchedulerComponent} from './my-auto-schedule-component';
import { MyPetSchedulerComponent} from './my-pet-schedule-component';
import { DropdownReminderComponent} from './dropdown-reminder-component';
import { InvitePopComponent} from './invite-pop-component';
import { UnpinPopComponent } from './unpin-pop-component';
import { PinToDashboardComponent} from './pin-to-dashboard-component';
import { CreditPointsComponent} from './credit-points-component';
import { CustomerCreditComponent } from './customer-credit-component';
import { CustomerCreditAbcComponent } from './customer-credit-abc-component';
import { MyHouseCalenderComponent } from './my-house-calender-component';
import { MyDoctorCalenderComponent} from './my-doctor-calender-component';
import { MyAutoCalenderComponent} from './my-auto-calender-component';
import { MySchedulerCalenderComponent} from './my-scheduler-calender-component';
import { MyPetCalenderComponent} from './my-pet-calender-component';
import { MyHouseUpdateComponent} from './my-house-update-component';
import { MyDoctorUpdateComponent } from './my-doctor-update-component';
import { MyAutoUpdateComponent} from './my-auto-update-component';
import { MyScheduleUpdateComponent} from './my-schedule-update-component';
import { MyPetScheduleUpdateComponent } from './my-pet-schedule-update-component';
import { CancelCouponsComponent} from './cancel-coupons-component';
import { MemberUpdateComponent} from './member-update-component';
import { DismissPopComponent} from './dismisspop-component';
import {NoViewInvoiceTemplateComponent} from './noview-invoice-template-component';
import { EmilyGreenDetailComponent} from './emily-green-detail-component';
import { ItemBusinessUpdateComponent } from './item-business-update-component';
import { BlockComponent } from './block-component';
//import { EditorModule } from '@tinymce/tinymce-angular';

@NgModule({
    imports: [
        CommonModule,
        NgbModule,
        RouterModule,
        LoginRoutingModule,
        MaterialModuleControls,
        BMSUxModule,
        FormsModule,
        ReactiveFormsModule,
        EditorModule
    ],
    declarations: [LoginComponent, IndividualDashboardComponent, BusinessDashboardComponent, ProfileIndividualComponent, SchedulerComponent, BusinessSchedulerComponent, HotelDashboardComponent, SalonDashboardComponent, DoctorDashboardComponent, EventsIndividualComponent, GroupsIndividualComponent, CancelComponent, EventsBusinessComponent, GroupsBusinessComponent, MembersBusinessComponent, ProfileBusinessComponent, AdditionalFeaturesComponent, BusinessAdditionalComponent, AdamComponent, SearchPopComponent, ItemsBusinessComponent, SalesHistoryBusinessComponent, SalesPopComponent, DeleteSaleHistoryComponent, MembersTransactionComponent, SuccessfullMessageComponent, PayementGateAwayComponent, StaffBusinessComponent, StaffPopComponent, IndividualRegistrationComponent, BusinessRegistrationComponent, CouponsBusinessComponent, EmailTemplateComponent, ViewTemplateComponent, NoViewTemplateComponent, ProfileIndividualPopComponent, IndividualProfileReminderPopComponent, DeleteReminderProfileIndividualComponent, CancelReminderProfileIndividualComponent, JoinPopIndividualDashboardComponent, UpdateBusinessProfileComponent, ReminderBusinessProfileComponent, DeleteBusinessComponent, GroupsUpdateComponent, EventsUpdateComponent, EventsBusinessUpdateComponent, GroupsBusinessUpdateComponent, ViewInvoiceTemplateComponent, InvoiceBusinessTemplateComponent, DoctorSchedulerComponent, MySchedulerComponent, MyHouseSchedulerComponent, MyAutoSchedulerComponent, MyPetSchedulerComponent, DropdownReminderComponent, InvitePopComponent, UnpinPopComponent, PinToDashboardComponent, CreditPointsComponent, CustomerCreditComponent, CustomerCreditAbcComponent, MyHouseCalenderComponent, MyDoctorCalenderComponent, MyAutoCalenderComponent, MySchedulerCalenderComponent, MyPetCalenderComponent, MyHouseUpdateComponent, MyDoctorUpdateComponent, MyScheduleUpdateComponent, MyPetScheduleUpdateComponent, MyAutoUpdateComponent, CancelCouponsComponent, MemberUpdateComponent, DismissPopComponent, NoViewInvoiceTemplateComponent, EmilyGreenDetailComponent, ItemBusinessUpdateComponent, BlockComponent],
    exports: [LoginComponent, IndividualDashboardComponent, BusinessDashboardComponent, ProfileIndividualComponent, SchedulerComponent, BusinessSchedulerComponent, HotelDashboardComponent, SalonDashboardComponent, DoctorDashboardComponent, EventsIndividualComponent, GroupsIndividualComponent, CancelComponent, EventsBusinessComponent, GroupsBusinessComponent, MembersBusinessComponent, ProfileBusinessComponent, AdditionalFeaturesComponent, BusinessAdditionalComponent, AdamComponent, SearchPopComponent, ItemsBusinessComponent, SalesHistoryBusinessComponent, SalesPopComponent, DeleteSaleHistoryComponent, MembersTransactionComponent, SuccessfullMessageComponent, PayementGateAwayComponent, StaffBusinessComponent, StaffPopComponent, IndividualRegistrationComponent, BusinessRegistrationComponent, CouponsBusinessComponent, EmailTemplateComponent, ViewTemplateComponent, NoViewTemplateComponent, ProfileIndividualPopComponent, IndividualProfileReminderPopComponent, DeleteReminderProfileIndividualComponent, CancelReminderProfileIndividualComponent, JoinPopIndividualDashboardComponent, UpdateBusinessProfileComponent, ReminderBusinessProfileComponent, DeleteBusinessComponent, GroupsUpdateComponent, EventsUpdateComponent, EventsBusinessUpdateComponent, GroupsBusinessUpdateComponent, ViewInvoiceTemplateComponent, InvoiceBusinessTemplateComponent, DoctorSchedulerComponent, MySchedulerComponent, MyHouseSchedulerComponent, MyAutoSchedulerComponent, MyPetSchedulerComponent, DropdownReminderComponent, InvitePopComponent, UnpinPopComponent, PinToDashboardComponent, CreditPointsComponent, CustomerCreditComponent, CustomerCreditAbcComponent, MyHouseCalenderComponent, MyDoctorCalenderComponent, MyAutoCalenderComponent, MySchedulerCalenderComponent, MyPetCalenderComponent, MyHouseUpdateComponent, MyDoctorUpdateComponent, MyScheduleUpdateComponent, MyPetScheduleUpdateComponent, MyAutoUpdateComponent, CancelCouponsComponent, MemberUpdateComponent, DismissPopComponent, NoViewInvoiceTemplateComponent, EmilyGreenDetailComponent, ItemBusinessUpdateComponent, BlockComponent],
    providers: [AppConfig],
    //entryComponents: [DialogAddComponent, DialogImageAddComponent, ERASComponent, PreAdmissionComponent, RiskAnalysispopComponent]
})


export class LoginModule { }