﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'profile-ind-pop-component',
    templateUrl: 'profile-ind-pop-component.html'
})

export class ProfileIndividualPopComponent {


    imgPath1: string = "./images/men.jpg"

    constructor(public dialogRef: MatDialogRef<ProfileIndividualPopComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}