﻿import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { DropdownReminderComponent } from './dropdown-reminder-component';
import { InvitePopComponent } from './invite-pop-component';
import { PinToDashboardComponent} from './pin-to-dashboard-component';
import { MyHouseUpdateComponent } from './my-house-update-component';
import { DeleteBusinessComponent} from './delete-business-component';
import { CancelCouponsComponent } from './cancel-coupons-component';
@Component({
    selector: 'my-house-schedule-component',
    templateUrl: 'my-house-schedule-component.html'
})

export class MyHouseSchedulerComponent {

    imgPath: string = "./images/no.jpg"
    imgPath1: string = "./images/home.svg"

    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog
    ) {
        this.shared.login = true;
    }

    Left() {
        this.router.navigate(['log/individual']);
    }

    Pin() {
        let dialogOpen = this.dialog.open(PinToDashboardComponent, {
            width: '30%',
            disableClose: true
        })
    }

    CreateSchedule() {
        this.router.navigate(['log/myhousecalender']);
    }
    drop() {
        let dialogOpen = this.dialog.open(DropdownReminderComponent, {
            width: '30%',
            disableClose: true
        })
    }


    invite() {
        let dialogOpen = this.dialog.open(InvitePopComponent, {
            width: '20%',
            disableClose: true
        })
    }

    update() {
        let dialogOpen = this.dialog.open(MyHouseUpdateComponent, {
            width: '40%',
            disableClose: true
        })
    } 

    deletepop() {
        let dialogOpen = this.dialog.open(DeleteBusinessComponent, {
            width: '20%',
            disableClose: true
        })
    }

    cancel() {
        let dialogOpen = this.dialog.open(CancelCouponsComponent, {
            width: '20%',
            disableClose: true
        })
    }
}