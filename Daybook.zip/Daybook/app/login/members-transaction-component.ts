﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'members-transaction-component',
    templateUrl: 'members-transaction-component.html'
})

export class MembersTransactionComponent {
    constructor(public dialogRef: MatDialogRef<MembersTransactionComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}