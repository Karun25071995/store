﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'pin-to-dashboard-component',
    templateUrl: 'pin-to-dashboard-component.html'
})

export class PinToDashboardComponent {
    constructor(public dialogRef: MatDialogRef<PinToDashboardComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}