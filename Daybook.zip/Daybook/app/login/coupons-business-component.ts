﻿import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { CancelComponent } from './cancel-component';
import { CancelCouponsComponent } from './cancel-coupons-component';
import { DeleteBusinessComponent } from './delete-business-component';

@Component({
    selector: 'coupons-business-component',
    templateUrl: 'coupons-business-component.html'
})

export class CouponsBusinessComponent {


    imgPath: string = "./images/home.svg"

    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog
    ) {
        this.shared.login = true;
    }

    Save() {
        this.router.navigate(['log/business']);
    }

    Back() {

        this.router.navigate(['log/business']);
    }

    cancel() {
        let dialogOpen = this.dialog.open(CancelCouponsComponent, {
            width: '20%',
            disableClose: true
        })
    }

    delete() {
        let dialogOpen = this.dialog.open(DeleteBusinessComponent, {
            width: '20%',
            disableClose: true
        })
    }
}