﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'credit-points-component',
    templateUrl: 'credit-points-component.html'
})

export class CreditPointsComponent {
    constructor(public dialogRef: MatDialogRef<CreditPointsComponent>) {



    }

    closePopUp() {
        this.dialogRef.close();
    }
}