﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'cancel-coupons-component',
    templateUrl: 'cancel-coupons-component.html'
})

export class CancelCouponsComponent {
    constructor(public dialogRef: MatDialogRef<CancelCouponsComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}