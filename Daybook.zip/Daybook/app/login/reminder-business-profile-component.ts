﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'reminder-business-profile-component',
    templateUrl: 'reminder-business-profile-component.html'
})

export class ReminderBusinessProfileComponent {


   

    constructor(public dialogRef: MatDialogRef<ReminderBusinessProfileComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}