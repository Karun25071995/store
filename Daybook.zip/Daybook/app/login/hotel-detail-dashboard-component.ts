﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'hotel-detail-dashboard-component',
    templateUrl: 'hotel-detail-dashboard-component.html'
})

export class HotelDashboardComponent {
    constructor(public dialogRef: MatDialogRef<HotelDashboardComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}