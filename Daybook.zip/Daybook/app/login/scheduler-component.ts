﻿import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
declare var $: any;

@Component({
    selector: 'scheduler-component',
    templateUrl: 'scheduler-component.html'
})


export class SchedulerComponent implements OnInit {


  

    imgPath: string = "./images/home.svg"

    constructor(
        private router: Router,
        private shared: SharedData
    ) {
        this.shared.login = true;
    }


    ngOnInit() {

        $(document).ready(function () {

            $('#calendar').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'agendaDay,month,agendaWeek,listWeek'
                },
                defaultDate: this.testdate,
                navLinks: true, // can click day/week names to navigate views
                editable: true,
                allDaySlot: false,
                allDayText: false,
                eventLimit: true, // allow "more" link when too many events
                defaultView: 'month',

                events: [

                    {
                        id: 999,
                        title: 'Repeating Event',
                        start: '2018-04-14T16:00:00'
                    },
                    {
                        id: 999,
                        title: 'Repeating Event',
                        start: '2018-04-16T16:00:00'
                    },
                    
                   
                    {
                        title: 'Blood Pressure Checkup',
                        start: '2018-06-30T10:00:00'
                    },
                    {
                        title: 'Oil Change',
                        start: '2018-06-16T11:00:00'
                    },

                    {
                        title: 'Tyre Rotation',
                        start: '2018-06-20T16:00:00'
                    },

                    {
                        title: 'Water Wash',
                        start: '2018-06-23T17:00:00'
                    },

                    {
                        title: 'Engine Cleaning',
                        start: '2018-06-26T15:00:00'
                    },
                    {
                        title: 'Brake Test',
                        start: '2018-06-29T12:00:00'
                    },
                    {
                        title: 'Spark Plug Replacement',
                        start: '2018-06-30T13:00:00'
                    },
                    {
                        title: 'Yoga',
                        start: '2018-06-16T06:00:00'
                    },
                    {
                        title: 'Music',
                        start: '2018-06-19T8:00:00'
                    },

                    {
                        title: 'Dance',
                        start: '2018-06-223T16:30:00'
                    },

                    {
                        title: 'Aerobics',
                        start: '2018-06-24T15:30:00'
                    },
                    {
                        title: 'Driving Class',
                        start: '2018-06-26T07:00:00'
                    },
                    {
                        title: 'Swimming',
                        start: '2018-06-283T8:30:00'
                    },
                    {
                        title: 'Kung-Fu',
                        start: '2018-06-30T05:30:00'
                    },
                    {
                        title: 'Grooming',
                        start: '2018-06-15T12:30:00'
                    },
                    {
                        title: 'Vet Doctor',
                        start: '2018-06-17T11:30:00'
                    },

                    {
                        title: 'Vaccination',
                        start: '2018-06-21T10:30:00'
                    },

                    {
                        title: 'Walking',
                        start: '2018-06-25T06:00:00'
                    },
                    {
                        title: 'Pet Bathing',
                        start: '2018-06-30T107:30:00'
                    },

                ]

            });

        });
    }

    turn() {
        this.router.navigate(["log/individual"]);
    }
}