﻿import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
declare var $: any;

@Component({
    selector: 'my-auto-calender-component',
    templateUrl: 'my-auto-calender-component.html'
})


export class MyAutoCalenderComponent implements OnInit {




    imgPath: string = "./images/home.svg"

    constructor(
        private router: Router,
        private shared: SharedData
    ) {
        this.shared.login = true;
    }


    ngOnInit() {

        $(document).ready(function () {

            $('#calendar').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'agendaDay,month,agendaWeek,listWeek'
                },
                defaultDate: this.testdate,
                navLinks: true, // can click day/week names to navigate views
                editable: true,
                allDaySlot: false,
                allDayText: false,
                eventLimit: true, // allow "more" link when too many events
                defaultView: 'month',


                events: [

                    {
                        id: 999,
                        title: 'Repeating Event',
                        start: '2018-04-14T16:00:00'
                    },
                    {
                        id: 999,
                        title: 'Repeating Event',
                        start: '2018-04-16T16:00:00'
                    },
                    {
                        title: 'Oil Change',
                        start: '2018-05-25T14:00:00'
                    },

                    {
                        title: 'Tire Rotation',
                        start: '2018-05-25T11:00:00'
                    },

                    {
                        title: 'Water Wash',
                        start: '2018-05-26T13:00:00'
                    },

                    {
                        title: 'Engine Cleaning',
                        start: '2018-05-26T15:00:00'
                    },

                ]
            });

        });
    }

    Back() {
        this.router.navigate(["log/individual"]);
    }

    turn() {
        this.router.navigate(["log/-auto"]);
    }
}