﻿import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { UpdateBusinessProfileComponent} from './update-business-profile-component';
import { ReminderBusinessProfileComponent} from './reminder-business-profile-component';
import { DeleteBusinessComponent } from './delete-business-component';
import { CancelReminderProfileIndividualComponent} from './cancel-reminder-profile-component';

@Component({
    selector: 'profile-business-component',
    templateUrl: 'profile-business-component.html'
})

export class ProfileBusinessComponent {


    imgPath: string = "./images/garage.jpg"
    imgPath1: string = "./images/home.svg"


    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog
    ) {
        this.shared.login = true;
    }

    Left() {
        this.router.navigate(['log/business']);
    }

    Back() {
        this.router.navigate(['log/business']);
    }

    getPop() {
        let dialogOpen = this.dialog.open(UpdateBusinessProfileComponent, {
            width: '40%',
           
            disableClose: true
        })
    }

    getReminder() {
        let dialogOpen = this.dialog.open(ReminderBusinessProfileComponent, {
            width: '40%',
          
            disableClose: true
        })
    }

    deleteDetails() {
        let dialogOpen = this.dialog.open(DeleteBusinessComponent, {
            width: '20%',
            disableClose: true
        })
    }

    cancelDetails() {
        let dialogOpen = this.dialog.open(CancelReminderProfileIndividualComponent, {
            width: '20%',
            disableClose: true
        })
    }

}

