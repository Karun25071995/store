﻿import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
declare var $: any;

@Component({
    selector: 'my-house-calender-component',
    templateUrl: 'my-house-calender-component.html'
})


export class MyHouseCalenderComponent implements OnInit {




    imgPath: string = "./images/home.svg"

    constructor(
        private router: Router,
        private shared: SharedData
    ) {
        this.shared.login = true;
    }


    ngOnInit() {

        $(document).ready(function () {

            $('#calendar').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'agendaDay,month,agendaWeek,listWeek'
                },
                defaultDate: this.testdate,
                navLinks: true, // can click day/week names to navigate views
                editable: true,
                allDaySlot: false,
                allDayText: false,
                eventLimit: true, // allow "more" link when too many events
                defaultView: 'month',


                events: [

                    {
                        id: 999,
                        title: 'Repeating Event',
                        start: '2018-04-14T16:00:00'
                    },
                    {
                        id: 999,
                        title: 'Repeating Event',
                        start: '2018-04-16T16:00:00'
                    },

                   
                    {
                        title: 'AC Repair',
                        start: '2018-06-154T10:00:00',

                    },
                    {
                        title: 'Gas Tank',
                        start: '2018-06-15T14:00:00',

                    },

                    {
                        title: 'Water Tank',
                        start: '2018-06-16T12:00:00',

                    },


                    {
                        title: 'Tiles Polishing',
                        start: '2018-06-18T17:00:00',

                    },
                    {
                        title: 'Septic Tank Cleaning',
                        start: '2018-06-20T9:30:00',

                    },
                    {
                        title: 'Plumbing',
                        start: '2018-06-23T15:00:00',

                    },
                    {
                        title: 'Washing Machine Repair',
                        start: '2018-06-25T11:30:00',

                    },
                    {
                        title: 'Dish Washer Repair',
                        start: '2018-06-27T17:00:00',

                    },
                    {
                        title: 'Refridgerator Service',
                        start: '2018-06-30T10:00:00',

                    },
                   
                   
                   
                ]
            });

        });
    }

    Back() {
        this.router.navigate(["log/individual"]);
    }


    turn() {
        this.router.navigate(["log/-myhouse"]);
    }
}