﻿import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { SalesPopComponent} from './salespop-component';
import { DeleteSaleHistoryComponent} from './delete-saleshistory-component';
import { AdamComponent} from './adam-component';


@Component({
    selector: 'sale-history-business-component',
    templateUrl: 'sale-history-business-component.html'
})

export class SalesHistoryBusinessComponent {

    imgPath1: string = "./images/no.jpg"
    imgPath: string = "./images/home.svg"

    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog
    ) {
        this.shared.login = true;
    }

    Left() {
        this.router.navigate(['log/business'])
    }
    Back() {
        this.router.navigate(['log/business'])
    }

    getSalespop() {
        let dialogOpen = this.dialog.open(SalesPopComponent, {
            width: '35%',
            disableClose: true
        })
    }

   deleteDetails() {
       let dialogOpen = this.dialog.open(DeleteSaleHistoryComponent, {
            width: '20%',
            disableClose: true
        })
    }

    getAdam() {
        let dialogOpen = this.dialog.open(AdamComponent, {
            width: '40%',
            disableClose: true
        })
    }
    //CreateSchedule() {
    //    this.router.navigate(['log/BusinessScheduler']);
    //}
}