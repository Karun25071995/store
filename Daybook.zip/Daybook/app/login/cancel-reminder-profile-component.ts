﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'cancel-reminder-profile-component',
    templateUrl: 'cancel-reminder-profile-component.html'
})

export class CancelReminderProfileIndividualComponent {
    constructor(public dialogRef: MatDialogRef<CancelReminderProfileIndividualComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}