﻿import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialog } from '@angular/material';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MaterialModuleControls } from './../material-module';
import { Router } from '@angular/router';
import { SharedData } from '../shared/shareddata';
import { MembersTransactionComponent } from './members-transaction-component';
import { ProfileIndividualPopComponent } from './profile-ind-pop-component';
import { IndividualProfileReminderPopComponent } from './ind-reminder-pop-component';
import { DeleteReminderProfileIndividualComponent } from './delete-reminder-profile-component';
import { CancelReminderProfileIndividualComponent } from './cancel-reminder-profile-component';
import { DeleteBusinessComponent } from './delete-business-component';

@Component({
    selector: 'profile-individual-component',
    templateUrl: 'profile-individual-component.html'
})

export class ProfileIndividualComponent implements OnInit {



    




    public reminderArray: Array<any> = [];
    public newAttribute = {

       

        'SNo': '3',
        'Reminder': 'Food Carnival',
        'Date': '04/08/2018',
        'Time': '8.00 AM',
        'Occurence': 'Once',


       

    };

    addFieldValue() {
        this.reminderArray.push(this.newAttribute);
    }

    deleteFieldValue(index) {
        this.reminderArray.splice(index, 1);
    }




  
    image1: string = "./images/men.jpg"
    imgPath: string = "./images/home.svg"


    constructor(
        private router: Router,
        private shared: SharedData,
        private dialog: MatDialog
    ) {
        this.shared.login = true;
    }

    ngOnInit() {




    }

    Left() {
        this.router.navigate(['log/individual']);
    }

    Back() {
        this.router.navigate(['log/individual']);
    }

    getPop() {
        let dialogOpen = this.dialog.open(ProfileIndividualPopComponent, {
            width: '40%',
            
            disableClose: true
        })
    }


    getRemPop() {
        let dialogOpen = this.dialog.open(IndividualProfileReminderPopComponent, {
            width: '40%',

            disableClose: true
        })
    }

    deleteDetails() {
        let dialogOpen = this.dialog.open(DeleteReminderProfileIndividualComponent, {
            width: '20%',
            disableClose: true
        })
    }


    cancelDetails() {
        let dialogOpen = this.dialog.open(CancelReminderProfileIndividualComponent, {
            width: '20%',
            disableClose: true
        })
    }

   

}

