﻿import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { LoginComponent } from './login.component';
import { IndividualDashboardComponent } from './individual-dashboard-component';
import { BusinessDashboardComponent } from './business-dashboard-component';
import { ProfileIndividualComponent } from './profile-individual-component';
import { SchedulerComponent } from './scheduler-component';
import { BusinessSchedulerComponent } from './business-scheduler-dashboard-component';
import { HotelDashboardComponent } from './hotel-detail-dashboard-component';
import { SalonDashboardComponent } from './salon-detail-dashboard-component';
import { DoctorDashboardComponent } from './doctor-detail-dashboard-component';
import { EventsIndividualComponent } from './events-individual-component';
import { GroupsIndividualComponent } from './groups-individual-component';
import { CancelComponent } from './cancel-component';
import { EventsBusinessComponent } from './events-business-component';
import { GroupsBusinessComponent } from './groups-business-component';
import { MembersBusinessComponent } from './members-business-component';
import { ProfileBusinessComponent } from './profile-business-component';
import { AdditionalFeaturesComponent} from './additional-features-component';
import { BusinessAdditionalComponent} from './business-additional-component';
import { AdamComponent} from './adam-component';
import { SearchPopComponent } from './searchpop-component';
import { ItemsBusinessComponent} from './items-business-component';
import { SalesHistoryBusinessComponent } from './sale-history-business-component';
import { SalesPopComponent} from './salespop-component';
import { DeleteSaleHistoryComponent} from './delete-saleshistory-component';
import { MembersTransactionComponent } from './members-transaction-component';
import { SuccessfullMessageComponent} from './successfull-message-component';
import { PayementGateAwayComponent} from './payement-gateaway-component';
import { StaffBusinessComponent } from './staff-business-component';
import { StaffPopComponent } from './staffpop-component';
import { IndividualRegistrationComponent } from './individual-registration-component';
import { BusinessRegistrationComponent} from './business-registration-component';
import { CouponsBusinessComponent } from './coupons-business-component';
import { EmailTemplateComponent} from './email-template-component';
import { ViewTemplateComponent } from './view-template-component';
import { NoViewTemplateComponent } from './noview-template-component';
import { ProfileIndividualPopComponent } from './profile-ind-pop-component';
import { IndividualProfileReminderPopComponent } from './ind-reminder-pop-component';
import { DeleteReminderProfileIndividualComponent} from './delete-reminder-profile-component';
import { CancelReminderProfileIndividualComponent } from './cancel-reminder-profile-component';
import { JoinPopIndividualDashboardComponent } from './join-pop-individual-dashboard-component';
import { UpdateBusinessProfileComponent } from './update-business-profile-component';
import { ReminderBusinessProfileComponent } from './reminder-business-profile-component';
import { DeleteBusinessComponent } from './delete-business-component';
import { GroupsUpdateComponent} from './groups-update-component';
import { EventsUpdateComponent} from './events-update-component';
import { EventsBusinessUpdateComponent } from './events-business-update-component';
import { GroupsBusinessUpdateComponent} from './groups-business-update-component';
import { ViewInvoiceTemplateComponent} from './view-invoice-template-component';
import { InvoiceBusinessTemplateComponent} from './invoice-business-template-component';
import { DoctorSchedulerComponent} from './doctor-schedule-component';
import { MySchedulerComponent} from './my-schedule-component';
import { MyHouseSchedulerComponent } from './my-house-schedule-component';
import { MyAutoSchedulerComponent } from './my-auto-schedule-component';
import { MyPetSchedulerComponent } from './my-pet-schedule-component';
import { DropdownReminderComponent } from './dropdown-reminder-component';
import { InvitePopComponent} from './invite-pop-component';
import { UnpinPopComponent } from './unpin-pop-component';
import { PinToDashboardComponent } from './pin-to-dashboard-component';
import { CreditPointsComponent} from './credit-points-component';
import { CustomerCreditComponent} from './customer-credit-component';
import { CustomerCreditAbcComponent } from './customer-credit-abc-component';
import { MyHouseCalenderComponent } from './my-house-calender-component';
import { MyDoctorCalenderComponent } from './my-doctor-calender-component';
import { MyAutoCalenderComponent } from './my-auto-calender-component';
import { MySchedulerCalenderComponent } from './my-scheduler-calender-component';
import { MyPetCalenderComponent } from './my-pet-calender-component';
import { MyHouseUpdateComponent } from './my-house-update-component';
import { MyDoctorUpdateComponent } from './my-doctor-update-component';
import { MyAutoUpdateComponent} from './my-auto-update-component';
import { MyScheduleUpdateComponent } from './my-schedule-update-component';
import { MyPetScheduleUpdateComponent} from './my-pet-schedule-update-component';
import { CancelCouponsComponent } from './cancel-coupons-component';
import { MemberUpdateComponent } from './member-update-component';
import { DismissPopComponent} from './dismisspop-component';
import { NoViewInvoiceTemplateComponent } from './noview-invoice-template-component';
import { EmilyGreenDetailComponent } from './emily-green-detail-component';
import { ItemBusinessUpdateComponent } from './item-business-update-component';
import { BlockComponent } from './block-component';

@NgModule({
    imports: [RouterModule.forChild([
        { path: 'log/loginpage', component: LoginComponent }  ,
        { path: 'log/individual', component: IndividualDashboardComponent },
        { path: 'log/business', component: BusinessDashboardComponent },
        { path: 'log/profile', component: ProfileIndividualComponent },
        { path: 'log/scheduler', component: SchedulerComponent },
        { path: 'log/BusinessScheduler', component: BusinessSchedulerComponent  },
        { path: 'log/HotelDetails', component: HotelDashboardComponent },
        { path: 'log/SalonDetails', component: SalonDashboardComponent },
        { path: 'log/DoctorDetails', component: DoctorDashboardComponent },
        { path: 'log/events', component: EventsIndividualComponent },
        { path: 'log/groups', component: GroupsIndividualComponent },
        { path: 'log/cancel', component: CancelComponent },
        { path: 'log/eventsBusiness', component: EventsBusinessComponent },
        { path: 'log/groupsBusiness', component: GroupsBusinessComponent },
        { path: 'log/membersBusiness', component: MembersBusinessComponent },
        { path: 'log/profile-business', component: ProfileBusinessComponent },
        { path: 'log/additional', component: AdditionalFeaturesComponent },
        { path: 'log/additional-business', component: BusinessAdditionalComponent },
        { path: 'log/adam', component: AdamComponent },
        { path: 'log/search', component: SearchPopComponent },
        { path: 'log/items-business', component: ItemsBusinessComponent },
        { path: 'log/saleshistory-business', component: SalesHistoryBusinessComponent },
        { path: 'log/salespop', component: SalesPopComponent },
        { path: 'log/delete-sales', component: DeleteSaleHistoryComponent },
        { path: 'log/transaction-details', component: MembersTransactionComponent },
        { path: 'log/success', component: SuccessfullMessageComponent },
        { path: 'log/payement', component: PayementGateAwayComponent },
        { path: 'log/staff', component: StaffBusinessComponent },
        { path: 'log/staffpop', component: StaffPopComponent },
        { path: 'log/individual-registration', component: IndividualRegistrationComponent },
        { path: 'log/business-registration', component: BusinessRegistrationComponent },
        { path: 'log/coupons', component: CouponsBusinessComponent },
        { path: 'log/email', component: EmailTemplateComponent },
        { path: 'log/view', component: ViewTemplateComponent },
        { path: 'log/noview', component: NoViewTemplateComponent },
        { path: 'log/profile-pop', component: ProfileIndividualPopComponent },
        { path: 'log/profile-reminder', component: IndividualProfileReminderPopComponent },
        { path: 'log/profile-delete', component: DeleteReminderProfileIndividualComponent },
        { path: 'log/profile-cancel', component: CancelReminderProfileIndividualComponent },
        { path: 'log/profile-join', component: JoinPopIndividualDashboardComponent },
        { path: 'log/profile-busipop', component: UpdateBusinessProfileComponent },
        { path: 'log/profile-reminder', component: ReminderBusinessProfileComponent },
        { path: 'log/profile-delete', component: DeleteBusinessComponent },
        { path: 'log/groups-update', component: GroupsUpdateComponent },
        { path: 'log/events-update', component: EventsUpdateComponent },
        { path: 'log/eventsbusiness-update', component: EventsBusinessUpdateComponent },
        { path: 'log/groupsbusiness-update', component: GroupsBusinessUpdateComponent },
        { path: 'log/view-invoice', component: ViewInvoiceTemplateComponent },
        { path: 'log/-invoice', component: InvoiceBusinessTemplateComponent },
        { path: 'log/-doctorschedule', component: DoctorSchedulerComponent },
        { path: 'log/-my', component: MySchedulerComponent },
        { path: 'log/-myhouse', component: MyHouseSchedulerComponent },
        { path: 'log/-auto', component: MyAutoSchedulerComponent },
        { path: 'log/-pet', component: MyPetSchedulerComponent },
        { path: 'log/-dropdown', component: DropdownReminderComponent },
        { path: 'log/invite', component: InvitePopComponent },
        { path: 'log/unpin', component: UnpinPopComponent },
        { path: 'log/pintodashboard', component: PinToDashboardComponent },
        { path: 'log/credit', component: CreditPointsComponent },
        { path: 'log/customercredit', component: CustomerCreditComponent },
        { path: 'log/customercreditabc', component: CustomerCreditAbcComponent },
        { path: 'log/myhousecalender', component: MyHouseCalenderComponent },
        { path: 'log/mydoctorcalender', component: MyDoctorCalenderComponent },
        { path: 'log/myautocalender', component: MyAutoCalenderComponent },
        { path: 'log/mycalender', component: MySchedulerCalenderComponent },
        { path: 'log/mypetcalender', component: MyPetCalenderComponent },
        { path: 'log/myhouseupdate', component: MyHouseUpdateComponent },
        { path: 'log/mydoctorupdate', component: MyDoctorUpdateComponent },
        { path: 'log/myautoupdate', component: MyAutoUpdateComponent },
        { path: 'log/myscheduleupdate', component: MyScheduleUpdateComponent },
        { path: 'log/mypetupdate', component: MyPetScheduleUpdateComponent },
        { path: 'log/cancelcoupons', component: CancelCouponsComponent },
        { path: 'log/memberupdate', component: MemberUpdateComponent },
        { path: 'log/dismiss', component: DismissPopComponent },
        { path: 'log/noview-invoice', component: NoViewInvoiceTemplateComponent },
        { path: 'log/emilygreen', component: EmilyGreenDetailComponent },
        { path: 'log/item-update', component: ItemBusinessUpdateComponent },
        { path: 'log/block', component: BlockComponent },
   
    ])],
    exports: [RouterModule]
})
export class LoginRoutingModule { }