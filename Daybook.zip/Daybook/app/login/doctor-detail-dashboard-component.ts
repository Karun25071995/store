﻿import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
    selector: 'doctor-detail-dashboard-component',
    templateUrl: 'doctor-detail-dashboard-component.html'
})

export class DoctorDashboardComponent {
    constructor(public dialogRef: MatDialogRef<DoctorDashboardComponent>) {

    }

    closePopUp() {
        this.dialogRef.close();
    }
}