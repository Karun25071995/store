﻿import { Location } from '@angular/common';
import { Injectable, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { BMSMessageBox, BMSMessageBoxColorMode, BMSMessageBoxMode } from './ux/bmsmsgbox/bmsmsgbox.component';
import { MatDialog } from '@angular/material';
import { AdminMenu, ProviderMenu, PatientMenu } from './app.constants';
import { SharedData } from '../app/shared/shareddata'
import { IMenu } from './../app/ux/bmsmenu/bmsmenu.component';



@Injectable()
export class AppConfig implements OnInit {
    public appMenus: Array<IMenu> = [];


    constructor(
        private router: Router,
        public dialog: MatDialog,
        private shared: SharedData
    ) {
    }

    ngOnInit() {
        
    }

    public populateMenu(role: string) {        

        if (this.appMenus.length > 0) {
            this.appMenus = [];
        }

        if (role == "Administrator") {
            this.appMenus.push(AdminMenu);
        }

        if (role == "Provider") {
            this.appMenus.push(ProviderMenu);
        }

        if (role == "Patient") {
            this.appMenus.push(PatientMenu);
        }
    }
}

