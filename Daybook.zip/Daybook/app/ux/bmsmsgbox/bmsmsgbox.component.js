"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
// import {NgbModal, NgbModalOptions, NgbActiveModal,  ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
const material_1 = require("@angular/material");
let BMSMessageBox = class BMSMessageBox {
    constructor(dialogRef
        // public activeModal: NgbActiveModal, public changeRef: ChangeDetectorRef
    ) {
        this.dialogRef = dialogRef;
        this.mode = BMSMessageBoxMode.MessageBox; // Mode of Message box - Values Message, Confirm
        this.colorMode = BMSMessageBoxColorMode.Information; //Mode for header color  - Info, Danger, Warning
        this.isInfo = true;
        this.isDanger = false;
        this.isWarning = false;
        //console.log("DialogComponent construct");
    }
    closeDialog(value) {
        this.dialogRef.close(value);
    }
    ngOnInit() {
        //console.log("DialogComponent init");
        switch (this.colorMode) {
            case BMSMessageBoxColorMode.Information: {
                this.isInfo = true;
                this.isDanger = false;
                this.isWarning = false;
                break;
            }
            case BMSMessageBoxColorMode.Danger:
                {
                    this.isInfo = false;
                    this.isDanger = true;
                    this.isWarning = false;
                    break;
                }
            case BMSMessageBoxColorMode.Warning:
                {
                    this.isInfo = false;
                    this.isDanger = false;
                    this.isWarning = true;
                    break;
                }
        }
    }
};
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], BMSMessageBox.prototype, "msgBoxTitle", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", String)
], BMSMessageBox.prototype, "message", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Number)
], BMSMessageBox.prototype, "mode", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Number)
], BMSMessageBox.prototype, "colorMode", void 0);
BMSMessageBox = __decorate([
    core_1.Component({
        // selector: 'bms-messagebox',
        templateUrl: 'bmsmsgbox.component.html'
    }),
    __metadata("design:paramtypes", [material_1.MatDialogRef])
], BMSMessageBox);
exports.BMSMessageBox = BMSMessageBox;
var BMSMessageBoxColorMode;
(function (BMSMessageBoxColorMode) {
    BMSMessageBoxColorMode[BMSMessageBoxColorMode["Information"] = 0] = "Information";
    BMSMessageBoxColorMode[BMSMessageBoxColorMode["Danger"] = 1] = "Danger";
    BMSMessageBoxColorMode[BMSMessageBoxColorMode["Warning"] = 2] = "Warning";
})(BMSMessageBoxColorMode = exports.BMSMessageBoxColorMode || (exports.BMSMessageBoxColorMode = {}));
var BMSMessageBoxMode;
(function (BMSMessageBoxMode) {
    BMSMessageBoxMode[BMSMessageBoxMode["MessageBox"] = 0] = "MessageBox";
    BMSMessageBoxMode[BMSMessageBoxMode["ConfrimBox"] = 1] = "ConfrimBox";
})(BMSMessageBoxMode = exports.BMSMessageBoxMode || (exports.BMSMessageBoxMode = {}));
//# sourceMappingURL=bmsmsgbox.component.js.map