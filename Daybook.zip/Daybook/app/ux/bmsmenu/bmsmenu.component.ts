import { Component, Input, OnInit, OnChanges, ViewContainerRef, Output, EventEmitter } from '@angular/core'
import { Router } from '@angular/router';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';


import { ColumnConfig, TableConfig } from '../columnConfig'

@Component({
    selector: 'bms-menu',
    templateUrl: 'bmsmenu.component.html'
})
export class BMSMenu implements OnInit, OnChanges {

    @Input()
    items: Array<IMenu>;
    menuOpen: boolean = true;
    currentMenuItem: string = "";


    ngOnInit() {

    }
    ngOnChanges() {

    }

    onSelctItem(event: any) {

        for (let i = 0; i < this.items.length; i++) {
            if (this.items[i].Title != event.Title) {
                this.items[i].isOpen = false;
            }
            else {
                if (this.menuOpen == true) {
                    this.items[i].isOpen = true;
                    this.currentMenuItem = this.items[i].Title;
                    this.menuOpen = false;
                }
                else {
                    if (this.items[i].Title == this.currentMenuItem) {
                        this.items[i].isOpen = false;
                        this.menuOpen = true;
                    }
                    else {
                        this.items[i].isOpen = true;
                        this.currentMenuItem = this.items[i].Title;
                        this.menuOpen = false;
                    }

                }
            }
        }
    }
}


export interface IMenu {
    Title: string;
    Url: string;
    isOpen?: boolean;
    Items?: Array<IMenu>;
}