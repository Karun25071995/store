"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const router_1 = require("@angular/router");
const columnConfig_1 = require("../columnConfig");
let BMSTable = class BMSTable {
    constructor(router) {
        this.router = router;
        this.datas = [];
        this.viewItem = new core_1.EventEmitter();
        this.addItem = new core_1.EventEmitter();
        this.editItem = new core_1.EventEmitter();
        this.selectItem = new core_1.EventEmitter();
        this.bindItem = new core_1.EventEmitter();
        this.deleteItem = new core_1.EventEmitter();
        this.showPager = false;
        this.totalRows = 0;
        this.filteredData = [];
        this.currentData = [];
        this.filters = [];
        this.totalRecords = 0;
        this.page = 1;
        this.pageSize = 10;
        this.selectedItems = [];
        this.selectAll = false;
        this.pageSizeOptions = [5, 10, 25, 100];
        this.orderBy = "";
        this.ascending = true;
    }
    getProperty(data, propertyName) {
        return Reflect.get(data, propertyName);
        //return Reflect.getMetadata(data, propertyName);
    }
    ngOnInit() {
        //this.currentData =  this.datas ? this.datas.slice(0, this.pageSize ) : [];
    }
    ngOnChanges(changes) {
        if (this.config != undefined) {
            for (let i = 0; i < this.config.columnConfig.length; i++) {
                if (this.config.columnConfig[i].isVisible == undefined) {
                    this.config.columnConfig[i].isVisible = true;
                }
                if (this.config.columnConfig[i].width == undefined) {
                    this.config.columnConfig[i].width = "150px";
                }
            }
        }
        if (this.datas != undefined) {
            this.filteredData = this.datas;
            this.configureTable();
            // if (this.config.showPagination) {
            //     this.totalRows = this.filteredData.length;
            //     this.currentData = this.filteredData.slice(0, this.pageSize);
            //     this.showPager = this.filteredData.length > 0 ? true : false;
            // }
            // else {
            //     this.currentData = this.filteredData;
            //     this.totalRows = this.filteredData.length;
            // }
        }
    }
    configureTable() {
        if (this.config.showPagination) {
            this.totalRows = this.filteredData.length;
            this.currentData = this.filteredData.slice(0, this.pageSize);
            this.showPager = this.filteredData.length > 0 ? true : false;
        }
        else {
            this.currentData = this.filteredData;
            this.totalRows = this.filteredData.length;
        }
    }
    onPageChange(page) {
        console.log(page);
        this.pageSize = page.pageSize;
        let pageNo = page.pageIndex;
        let startData = (pageNo) * page.pageSize;
        let endData = (pageNo + 1) * page.pageSize;
        this.totalRows = this.filteredData.length;
        this.currentData = this.filteredData.slice(startData, endData);
        this.selectAll = false;
        this.selectedItems = [];
    }
    goToDetail(event) {
        this.viewItem.emit(event);
    }
    goToEdit(event) {
        //this.router.navigate([this.config.EditNavgationLink, Id]);
        this.editItem.emit(event);
    }
    goToAdd(event) {
        //this.router.navigate([this.config.EditNavgationLink, Id]);
        this.addItem.emit({ Event: event });
    }
    goToDelete(event) {
        //console.log(data);       
        this.deleteItem.emit(event);
    }
    setOrder(colConfig) {
        if (this.orderBy == colConfig.PropertyName) {
            this.ascending = !this.ascending;
        }
        else {
            this.orderBy = colConfig.PropertyName;
            this.ascending = true;
        }
        let chkConst = this.ascending ? -1 : 1;
        this.filteredData.sort((left, right) => {
            if (this.getProperty(left, this.orderBy) < this.getProperty(right, this.orderBy))
                return 1 * chkConst;
            if (this.getProperty(left, this.orderBy) > this.getProperty(right, this.orderBy))
                return -1 * chkConst;
            return 0;
        });
        this.configureTable();
    }
    onSelectAll(event) {
        let checked;
        if (event.target) {
            checked = event.target.checked;
        }
        else if (event.srcElement) {
            checked = event.srcElement.checked;
        }
        if (this.currentData) {
            for (let i = 0; i < this.currentData.length; i++) {
                this.currentData[i].checked = checked;
            }
            this.selectedItems = [];
            if (checked) {
                this.selectedItems = this.currentData.slice();
            }
            this.selectItem.emit({ Event: event, Item: undefined, Checked: checked, SelectedItems: this.selectedItems });
        }
    }
    onSelect(event) {
        let checked = event.Checked;
        if (checked) {
            this.selectedItems.push(event.Item);
        }
        else {
            let index = this.selectedItems.indexOf(event.Item);
            let temp = [];
            for (let i = 0; i < this.selectedItems.length; i++) {
                if (i != index) {
                    temp.push(this.selectedItems[i]);
                }
            }
            this.selectedItems = temp;
            //this.selectedItems.slice(index, 1);
        }
        this.selectItem.emit({ Event: event, SelectedItems: this.selectedItems });
    }
    onBindItem(event) {
        this.bindItem.emit(event);
    }
    showFilter(colConfig) {
        colConfig.showFilterLoading = true;
        colConfig.filters = this.getFilterValues(colConfig);
        colConfig.showFilterLoading = false;
    }
    filterData(colConfig, value) {
        this.filteredData = this.filteredData.filter(x => this.getProperty(x, colConfig.PropertyName) == value);
        this.configureTable();
        colConfig.filtered = true;
        colConfig.filterValue = value;
    }
    clearFilter(colConfig) {
        colConfig.filtered = false;
        colConfig.filterValue = "";
        this.filteredData = this.datas;
        for (let i = 0; i < this.config.columnConfig.length; i++) {
            if (this.config.columnConfig[i].filtered) {
                this.filterData(this.config.columnConfig[i], this.config.columnConfig[i].filterValue);
            }
        }
        this.configureTable();
    }
    getFilterValues(colConfig) {
        let filterValues = [];
        for (let i = 0; i < this.filteredData.length; i++) {
            if (filterValues.filter(x => x.value == this.getProperty(this.filteredData[i], colConfig.PropertyName)).length == 0) {
                filterValues.push({ value: this.getProperty(this.filteredData[i], colConfig.PropertyName) });
            }
        }
        return filterValues;
    }
};
__decorate([
    core_1.Input(),
    __metadata("design:type", Array)
], BMSTable.prototype, "datas", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", columnConfig_1.TableConfig)
], BMSTable.prototype, "config", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], BMSTable.prototype, "viewItem", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], BMSTable.prototype, "addItem", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], BMSTable.prototype, "editItem", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], BMSTable.prototype, "selectItem", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], BMSTable.prototype, "bindItem", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], BMSTable.prototype, "deleteItem", void 0);
BMSTable = __decorate([
    core_1.Component({
        selector: 'bms-table',
        templateUrl: 'bms-table.component.html'
    }),
    __metadata("design:paramtypes", [router_1.Router])
], BMSTable);
exports.BMSTable = BMSTable;
//# sourceMappingURL=bms-table.component.js.map