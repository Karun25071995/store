"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@angular/core");
const columnConfig_1 = require("../columnConfig");
let BMSTableRow = class BMSTableRow {
    constructor() {
        this.viewItem = new core_1.EventEmitter();
        this.editItem = new core_1.EventEmitter();
        this.selectItem = new core_1.EventEmitter();
        this.bindItem = new core_1.EventEmitter();
        this.deleteItem = new core_1.EventEmitter();
        this.showView = false;
        this.showEdit = false;
        this.showDelete = false;
    }
    ngOnInit() {
    }
    ngOnChanges(changes) {
        this.data.showView = this.config.showView;
        this.data.showEdit = this.config.showEdit;
        this.data.showDelete = this.config.showDelete;
        this.bindItem.emit({ Item: this.data });
    }
    getProperty(data, propertyName) {
        return Reflect.get(data, propertyName);
        //return Reflect.getMetadata(data, propertyName);
    }
    goToDetail(event, data) {
        //console.log(data);
        this.viewItem.emit({ Event: event, Item: data });
    }
    goToEdit(event, data) {
        //console.log(data);
        //this.router.navigate([this.config.EditNavgationLink, Id]);
        this.editItem.emit({ Event: event, Item: data });
    }
    goToDelete(event, data) {
        //console.log(data);       
        this.deleteItem.emit({ Event: event, Item: data });
    }
    onSelect(event, data) {
        let checked;
        if (event.target) {
            checked = event.target.checked;
        }
        else if (event.srcElement) {
            checked = event.srcElement.checked;
        }
        this.selectItem.emit({ Event: event, Checked: checked, Item: data });
    }
};
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], BMSTableRow.prototype, "data", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", columnConfig_1.TableConfig)
], BMSTableRow.prototype, "config", void 0);
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], BMSTableRow.prototype, "index", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], BMSTableRow.prototype, "viewItem", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], BMSTableRow.prototype, "editItem", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], BMSTableRow.prototype, "selectItem", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], BMSTableRow.prototype, "bindItem", void 0);
__decorate([
    core_1.Output(),
    __metadata("design:type", Object)
], BMSTableRow.prototype, "deleteItem", void 0);
BMSTableRow = __decorate([
    core_1.Component({
        selector: 'bms-tablerow',
        templateUrl: 'bms-tablerow.component.html'
    })
], BMSTableRow);
exports.BMSTableRow = BMSTableRow;
//# sourceMappingURL=bms-tablerow.component.js.map