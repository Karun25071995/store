"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class TableConfig {
    constructor() {
        this.showPagination = true;
        this.showSelection = false;
        this.showView = false; // Whether to show View option in table
        // public NavgationLink?:string;    // Router Url
        // public NavigationField?:string;  // Router ID
        this.showEdit = false; // Whether to show Edit option in table
        this.showAdd = false; // Whether to show Add option in table
        this.showDelete = false; // Whether to show delete option in table
        this.columnConfig = []; // Array of ColumnConfig. Will be shown in the table
    }
}
exports.TableConfig = TableConfig;
//# sourceMappingURL=columnConfig.js.map