import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpModule } from '@angular/http';
import { Routes, RouterModule } from '@angular/router';

import { Ng2OrderModule } from 'ng2-order-pipe';

import { ColumnConfig}  from './columnConfig'
import { BMSTable } from './bmsTable/bms-table.component'
import { BMSTableRow } from './bmsTable/bms-tablerow.component'
import { BMSTableCell } from './bmsTable/bms-tablecell.component'
import { BMSMessageBox} from './bmsmsgbox/bmsmsgbox.component'

import { BMSMenu, IMenu} from './bmsmenu/bmsmenu.component'
import { BMSMenuItem }from './bmsmenu/bmsmenu-item.component'
import { MaterialModuleControls } from './../material-module';

@NgModule({
    imports: [
        CommonModule,
        NgbModule,
        FormsModule,
        HttpModule,
        RouterModule,
        Ng2OrderModule,
        MaterialModuleControls
    ],
    declarations: [BMSTable, BMSTableRow, BMSTableCell, BMSMenuItem, BMSMenu],
    providers: [],
    exports: [BMSTable, BMSTableRow, BMSTableCell, BMSMenuItem, BMSMenu, CommonModule],
    entryComponents: [BMSMessageBox]
})
export class BMSUxModule { }  