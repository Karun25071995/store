﻿import { Injectable, EventEmitter } from '@angular/core';
import { Headers, Http } from '@angular/http';
import { AppConfig } from '../app-config';
import { SPUserData } from '../login/SPUserData';

@Injectable()
export class SharedData {

    public LoginUser: SPUserData = new SPUserData();
    public login: boolean = false;

    constructor() {
        this.LoginUser = { "UserName": "", "Password": "", "Facility": "", "Role": "" };
    }


    //userEvent: EventEmitter<any> = new EventEmitter();



    //public getCurrentUserDetails() {
    //    return this.http.get(this.appConfig.eInvoiceWebUrl + "Users/Users.svc/CurrentUser", { "headers": this.appConfig.headers }).map((currentUserItem: any) => {
    //        currentUserItem.json()
    //    }).subscribe((data: any) => {
    //        console.log(data)
    //        this.userEvent.emit(data.list1);
    //    }
    //        );
    //}

}