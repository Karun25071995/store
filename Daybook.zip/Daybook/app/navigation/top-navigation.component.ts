import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MaterialModuleControls } from './../material-module';
import { SharedData } from '../../app/shared/shareddata'

@Component({
    selector: 'top-navigation',
    templateUrl: 'top-navigation.component.html'
})
export class TopNavigationComponent implements OnInit {

    imgnotify: string;

    constructor(private shared: SharedData, private router: Router) {
    }

    ngOnInit() {
        this.imgnotify = './images/notification.png';
    }

    logOut() {
        this.router.navigate(['log/loginpage']);
    }
}
