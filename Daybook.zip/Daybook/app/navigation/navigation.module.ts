import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TopNavigationComponent } from './top-navigation.component'
import { MainNavigationComponent } from './main-navigation.component'
import { MaterialModuleControls } from '../material-module';
import { BMSUxModule } from '../ux/bms.ux.module';


@NgModule({
    imports: [
        CommonModule,
        NgbModule,
        RouterModule,
        BMSUxModule,
        MaterialModuleControls
    ],
    declarations: [TopNavigationComponent, MainNavigationComponent],
    providers: [],
    exports: [TopNavigationComponent, MainNavigationComponent],
    entryComponents: []
})
export class NavigationModule { }  