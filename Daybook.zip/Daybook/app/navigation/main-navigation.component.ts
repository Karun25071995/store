import { Component } from '@angular/core';
import { AppConfig } from '../app-config';


@Component({
    selector: 'main-navigation',
    templateUrl: 'main-navigation.component.html'
})
export class MainNavigationComponent {

    constructor(private appConfig: AppConfig) {       

    }
}
