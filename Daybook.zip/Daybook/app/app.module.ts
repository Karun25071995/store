import { NgModule, ModuleWithProviders } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';
import { EditorModule } from '@tinymce/tinymce-angular';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModuleControls } from './material-module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap'
import { Ng2OrderModule } from 'ng2-order-pipe';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { AppConfig } from './app-config';
/* App Root */
import { AppComponent } from './app.component';
import { BMSMessageBox } from './ux/bmsmsgbox/bmsmsgbox.component'

/* Routing Module */
import { AppRoutingModule } from './app-routing.module';

/* Custom Module */
import { NavigationModule } from './navigation/navigation.module';
//import { InvoiceModule } from './invoices/invoice-module';
//import { ConfigurationModule } from './configuration/configuration-module';
//import { InvoiceChartModule } from './invoicecharts/invoice-chart-module';
import { SharedModule } from './shared/shared.module'
import { LoginModule } from './login/login.module'

@NgModule({
    imports: [
        BrowserModule,
        RouterModule,
        EditorModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule.forRoot(),
        NavigationModule,
        LoginModule,
        MaterialModuleControls,
        HttpModule,
        NgbModule.forRoot(),        
        Ng2OrderModule,
        NgxChartsModule,
        BrowserAnimationsModule,
        AppRoutingModule
        
    ],

    declarations: [AppComponent, BMSMessageBox],
    bootstrap: [AppComponent],
    entryComponents: [BMSMessageBox]

})

export class AppModule { }

