﻿/**Reflect must come in top to avoid  errors*/
/** IE9, IE10 and IE11 requires all of the following polyfills. **/
import 'core-js/es6/symbol';
import 'core-js/es6/object';
import 'core-js/es6/function';
import 'core-js/es6/parse-int';
import 'core-js/es6/parse-float';
import 'core-js/es6/number';
import 'core-js/es6/math';
import 'core-js/es6/string';
import 'core-js/es6/date';
import 'core-js/es6/array';
import 'core-js/es6/regexp';
import 'core-js/es6/map';
import 'core-js/es6/set';

/** Evergreen browsers require these. **/
import 'core-js/es6/reflect';
import 'core-js/es7/reflect';
import 'core-js';
import 'core-js/es7/array';
import 'classlist.js'; /** For Swimline Charts */

import 'es6-promise/dist/es6-promise';
import 'whatwg-fetch';

import "reflect-metadata"
import 'zone.js/dist/zone';

import 'jquery';
import 'tether';

// import 'bootstrap/dist/js/bootstrap';
// import 'bootstrap/dist/css/bootstrap.min.css';

import '@angular/core';
import '@angular/platform-browser';
import '@angular/router';
import '@angular/http';
import '@angular/forms';
import '@angular/common';
import '@angular/compiler';
import '@angular/platform-browser-dynamic';
import '@angular/animations';
import 'rxjs';


/** ng-bootstrap components module */
// import '@ng-bootstrap/ng-bootstrap'


/** Material components module */
import '@angular/material';

import 'hammerjs';

/** SP-PNP-JS module used for SharePoint operations */
import "sp-pnp-js";

/**** Charts Module */
import '@swimlane/ngx-charts';

import 'd3';

/**** Sort Pipe Module  */
import 'ng2-order-pipe';


